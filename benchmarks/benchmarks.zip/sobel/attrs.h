#define ATTR1 Cyber array=REG
#define ATTR2 Cyber unroll_times=REG
#define ATTR3 Cyber unroll_times=REG
#define ATTR4 Cyber unroll_times=all
#define ATTR5 Cyber unroll_times=all
#define ATTR5 Cyber unroll_times=all

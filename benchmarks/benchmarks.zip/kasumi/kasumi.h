/*---------------------------------------------------------
* Kasumi.h
*---------------------------------------------------------*/
#ifndef KASUMI_H
#define KASUMI_H

typedef unsigned char u8;
typedef unsigned short u16;
typedef unsigned long u32;


/*--------- 16 bit rotate left ------------------------------------------*/
#define ROL16(a,b) (u16)((a<<b)|(a>>(16-b)))

/*------- unions: used to remove "endian" issues ------------------------*/
// BCS: union not supported for synthesis
//typedef union {
//	u32 b32;
//	u16 b16[2];
//	u8 b8[4];
//} DWORD;
typedef struct dword{
	u8 b8[4];
}DWORD; 

//typedef union {
//	u16 b16;
//	u8 b8[2];
//} WORD;

typedef struct word {
	u8 b8[2];
} WORD;

/*-------- globals: The subkey arrays -----------------------------------*/
shared u16 KLi1[8]/* nCyber array = EXPAND, array_index=const*/, KLi2[8]/* nCyber array = EXPAND, array_index=const */;
shared u16 KOi1[8]/* nCyber array = EXPAND, array_index=const */, KOi2[8]/* nCyber array = EXPAND, array_index=const */, KOi3[8]/* nCyber array = EXPAND, array_index=const */;
shared u16 KIi1[8]/* nCyber array = EXPAND, array_index=const */, KIi2[8]/* nCyber array = EXPAND , array_index=const*/, KIi3[8]/* nCyber array = EXPAND, array_index=const */;


#endif // KASUMI_H

